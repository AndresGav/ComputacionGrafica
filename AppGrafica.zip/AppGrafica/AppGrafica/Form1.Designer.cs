﻿namespace AppGrafica
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.parcial1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.encerderPixelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pintarBanderaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.degradarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parabolaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lazoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.margaritaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.encenderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.apagarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gFuncionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.animacionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deberesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.graficosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.graficoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.examenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.correcionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.planoCartesianoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.animacionToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.parcial2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.axonometriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.segmento3DToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.superficieVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo1ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo4HiperboloiddeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.superficieRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo2ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo3ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipo6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tapetesDeberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aguaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hieloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parcialIIIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.labelX = new System.Windows.Forms.Label();
            this.labelY = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DarkGray;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(0, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(700, 500);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.Location = new System.Drawing.Point(710, 432);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 88);
            this.button2.TabIndex = 8;
            this.button2.Text = "LIMPIAR ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.parcial1ToolStripMenuItem,
            this.parcial2ToolStripMenuItem,
            this.parcialIIIToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(822, 24);
            this.menuStrip1.TabIndex = 19;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // parcial1ToolStripMenuItem
            // 
            this.parcial1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.encerderPixelToolStripMenuItem,
            this.pintarBanderaToolStripMenuItem,
            this.parabolaToolStripMenuItem,
            this.lazoToolStripMenuItem,
            this.margaritaToolStripMenuItem,
            this.gFuncionesToolStripMenuItem,
            this.testsToolStripMenuItem,
            this.deberesToolStripMenuItem,
            this.examenToolStripMenuItem,
            this.planoCartesianoToolStripMenuItem,
            this.animacionToolStripMenuItem1});
            this.parcial1ToolStripMenuItem.Name = "parcial1ToolStripMenuItem";
            this.parcial1ToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.parcial1ToolStripMenuItem.Text = "Parcial I";
            // 
            // encerderPixelToolStripMenuItem
            // 
            this.encerderPixelToolStripMenuItem.Name = "encerderPixelToolStripMenuItem";
            this.encerderPixelToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.encerderPixelToolStripMenuItem.Text = "Encerder Pixel";
            this.encerderPixelToolStripMenuItem.Click += new System.EventHandler(this.encerderPixelToolStripMenuItem_Click);
            // 
            // pintarBanderaToolStripMenuItem
            // 
            this.pintarBanderaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.degradarToolStripMenuItem,
            this.normalToolStripMenuItem});
            this.pintarBanderaToolStripMenuItem.Name = "pintarBanderaToolStripMenuItem";
            this.pintarBanderaToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.pintarBanderaToolStripMenuItem.Text = "Pintar Bandera";
            // 
            // degradarToolStripMenuItem
            // 
            this.degradarToolStripMenuItem.Name = "degradarToolStripMenuItem";
            this.degradarToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.degradarToolStripMenuItem.Text = "Degradar";
            this.degradarToolStripMenuItem.Click += new System.EventHandler(this.degradarToolStripMenuItem_Click);
            // 
            // normalToolStripMenuItem
            // 
            this.normalToolStripMenuItem.Name = "normalToolStripMenuItem";
            this.normalToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.normalToolStripMenuItem.Text = "Normal";
            this.normalToolStripMenuItem.Click += new System.EventHandler(this.normalToolStripMenuItem_Click);
            // 
            // parabolaToolStripMenuItem
            // 
            this.parabolaToolStripMenuItem.Name = "parabolaToolStripMenuItem";
            this.parabolaToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.parabolaToolStripMenuItem.Text = "Parabola";
            this.parabolaToolStripMenuItem.Click += new System.EventHandler(this.parabolaToolStripMenuItem_Click);
            // 
            // lazoToolStripMenuItem
            // 
            this.lazoToolStripMenuItem.Name = "lazoToolStripMenuItem";
            this.lazoToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.lazoToolStripMenuItem.Text = "Lazo";
            this.lazoToolStripMenuItem.Click += new System.EventHandler(this.lazoToolStripMenuItem_Click);
            // 
            // margaritaToolStripMenuItem
            // 
            this.margaritaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.encenderToolStripMenuItem,
            this.apagarToolStripMenuItem});
            this.margaritaToolStripMenuItem.Name = "margaritaToolStripMenuItem";
            this.margaritaToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.margaritaToolStripMenuItem.Text = "Margarita";
            // 
            // encenderToolStripMenuItem
            // 
            this.encenderToolStripMenuItem.Name = "encenderToolStripMenuItem";
            this.encenderToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.encenderToolStripMenuItem.Text = "Encender";
            this.encenderToolStripMenuItem.Click += new System.EventHandler(this.encenderToolStripMenuItem_Click);
            // 
            // apagarToolStripMenuItem
            // 
            this.apagarToolStripMenuItem.Name = "apagarToolStripMenuItem";
            this.apagarToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.apagarToolStripMenuItem.Text = "Apagar";
            this.apagarToolStripMenuItem.Click += new System.EventHandler(this.apagarToolStripMenuItem_Click);
            // 
            // gFuncionesToolStripMenuItem
            // 
            this.gFuncionesToolStripMenuItem.Name = "gFuncionesToolStripMenuItem";
            this.gFuncionesToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.gFuncionesToolStripMenuItem.Text = "G Funciones";
            this.gFuncionesToolStripMenuItem.Click += new System.EventHandler(this.gFuncionesToolStripMenuItem_Click);
            // 
            // testsToolStripMenuItem
            // 
            this.testsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.animacionToolStripMenuItem});
            this.testsToolStripMenuItem.Name = "testsToolStripMenuItem";
            this.testsToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.testsToolStripMenuItem.Text = "Tests";
            this.testsToolStripMenuItem.Click += new System.EventHandler(this.testsToolStripMenuItem_Click);
            // 
            // animacionToolStripMenuItem
            // 
            this.animacionToolStripMenuItem.Name = "animacionToolStripMenuItem";
            this.animacionToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.animacionToolStripMenuItem.Text = "Animacion";
            this.animacionToolStripMenuItem.Click += new System.EventHandler(this.animacionToolStripMenuItem_Click);
            // 
            // deberesToolStripMenuItem
            // 
            this.deberesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.graficosToolStripMenuItem,
            this.graficoToolStripMenuItem1});
            this.deberesToolStripMenuItem.Name = "deberesToolStripMenuItem";
            this.deberesToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.deberesToolStripMenuItem.Text = "Deberes";
            // 
            // graficosToolStripMenuItem
            // 
            this.graficosToolStripMenuItem.Name = "graficosToolStripMenuItem";
            this.graficosToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.graficosToolStripMenuItem.Text = "5 Graficos";
            this.graficosToolStripMenuItem.Click += new System.EventHandler(this.graficosToolStripMenuItem_Click);
            // 
            // graficoToolStripMenuItem1
            // 
            this.graficoToolStripMenuItem1.Name = "graficoToolStripMenuItem1";
            this.graficoToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.graficoToolStripMenuItem1.Text = "Grafico";
            this.graficoToolStripMenuItem1.Click += new System.EventHandler(this.graficoToolStripMenuItem1_Click);
            // 
            // examenToolStripMenuItem
            // 
            this.examenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.correcionToolStripMenuItem});
            this.examenToolStripMenuItem.Name = "examenToolStripMenuItem";
            this.examenToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.examenToolStripMenuItem.Text = "Examen";
            this.examenToolStripMenuItem.Click += new System.EventHandler(this.examenToolStripMenuItem_Click);
            // 
            // correcionToolStripMenuItem
            // 
            this.correcionToolStripMenuItem.Name = "correcionToolStripMenuItem";
            this.correcionToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.correcionToolStripMenuItem.Text = "Correcion";
            this.correcionToolStripMenuItem.Click += new System.EventHandler(this.correcionToolStripMenuItem_Click);
            // 
            // planoCartesianoToolStripMenuItem
            // 
            this.planoCartesianoToolStripMenuItem.Name = "planoCartesianoToolStripMenuItem";
            this.planoCartesianoToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.planoCartesianoToolStripMenuItem.Text = "Plano Cartesiano";
            this.planoCartesianoToolStripMenuItem.Click += new System.EventHandler(this.planoCartesianoToolStripMenuItem_Click);
            // 
            // animacionToolStripMenuItem1
            // 
            this.animacionToolStripMenuItem1.Name = "animacionToolStripMenuItem1";
            this.animacionToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
            this.animacionToolStripMenuItem1.Text = "Animacion ";
            this.animacionToolStripMenuItem1.Click += new System.EventHandler(this.animacionToolStripMenuItem1_Click);
            // 
            // parcial2ToolStripMenuItem
            // 
            this.parcial2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.axonometriaToolStripMenuItem,
            this.segmento3DToolStripMenuItem,
            this.superficieVToolStripMenuItem,
            this.superficieRToolStripMenuItem,
            this.paletasToolStripMenuItem,
            this.tapetesDeberToolStripMenuItem});
            this.parcial2ToolStripMenuItem.Name = "parcial2ToolStripMenuItem";
            this.parcial2ToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.parcial2ToolStripMenuItem.Text = "Parcial II";
            // 
            // axonometriaToolStripMenuItem
            // 
            this.axonometriaToolStripMenuItem.Name = "axonometriaToolStripMenuItem";
            this.axonometriaToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.axonometriaToolStripMenuItem.Text = "Axonometria";
            this.axonometriaToolStripMenuItem.Click += new System.EventHandler(this.axonometriaToolStripMenuItem_Click);
            // 
            // segmento3DToolStripMenuItem
            // 
            this.segmento3DToolStripMenuItem.Name = "segmento3DToolStripMenuItem";
            this.segmento3DToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.segmento3DToolStripMenuItem.Text = "Segmento 3D";
            this.segmento3DToolStripMenuItem.Click += new System.EventHandler(this.segmento3DToolStripMenuItem_Click);
            // 
            // superficieVToolStripMenuItem
            // 
            this.superficieVToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tipo1ToolStripMenuItem2,
            this.tipo2ToolStripMenuItem1,
            this.tipo3ToolStripMenuItem,
            this.tipo4HiperboloiddeToolStripMenuItem});
            this.superficieVToolStripMenuItem.Name = "superficieVToolStripMenuItem";
            this.superficieVToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.superficieVToolStripMenuItem.Text = "Superficie V";
            // 
            // tipo1ToolStripMenuItem2
            // 
            this.tipo1ToolStripMenuItem2.Name = "tipo1ToolStripMenuItem2";
            this.tipo1ToolStripMenuItem2.Size = new System.Drawing.Size(185, 22);
            this.tipo1ToolStripMenuItem2.Text = "Tipo 1";
            this.tipo1ToolStripMenuItem2.Click += new System.EventHandler(this.tipo1ToolStripMenuItem2_Click);
            // 
            // tipo2ToolStripMenuItem1
            // 
            this.tipo2ToolStripMenuItem1.Name = "tipo2ToolStripMenuItem1";
            this.tipo2ToolStripMenuItem1.Size = new System.Drawing.Size(185, 22);
            this.tipo2ToolStripMenuItem1.Text = "Tipo 2";
            this.tipo2ToolStripMenuItem1.Click += new System.EventHandler(this.tipo2ToolStripMenuItem1_Click);
            // 
            // tipo3ToolStripMenuItem
            // 
            this.tipo3ToolStripMenuItem.Name = "tipo3ToolStripMenuItem";
            this.tipo3ToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.tipo3ToolStripMenuItem.Text = "Tipo 3";
            this.tipo3ToolStripMenuItem.Click += new System.EventHandler(this.tipo3ToolStripMenuItem_Click);
            // 
            // tipo4HiperboloiddeToolStripMenuItem
            // 
            this.tipo4HiperboloiddeToolStripMenuItem.Name = "tipo4HiperboloiddeToolStripMenuItem";
            this.tipo4HiperboloiddeToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.tipo4HiperboloiddeToolStripMenuItem.Text = "Tipo 4 Hiperboloidde";
            this.tipo4HiperboloiddeToolStripMenuItem.Click += new System.EventHandler(this.tipo4HiperboloiddeToolStripMenuItem_Click);
            // 
            // superficieRToolStripMenuItem
            // 
            this.superficieRToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tipo1ToolStripMenuItem1,
            this.tipo2ToolStripMenuItem});
            this.superficieRToolStripMenuItem.Name = "superficieRToolStripMenuItem";
            this.superficieRToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.superficieRToolStripMenuItem.Text = "Superficie R";
            // 
            // tipo1ToolStripMenuItem1
            // 
            this.tipo1ToolStripMenuItem1.Name = "tipo1ToolStripMenuItem1";
            this.tipo1ToolStripMenuItem1.Size = new System.Drawing.Size(106, 22);
            this.tipo1ToolStripMenuItem1.Text = "Tipo 1";
            this.tipo1ToolStripMenuItem1.Click += new System.EventHandler(this.tipo1ToolStripMenuItem1_Click);
            // 
            // tipo2ToolStripMenuItem
            // 
            this.tipo2ToolStripMenuItem.Name = "tipo2ToolStripMenuItem";
            this.tipo2ToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.tipo2ToolStripMenuItem.Text = "Tipo 2";
            this.tipo2ToolStripMenuItem.Click += new System.EventHandler(this.tipo2ToolStripMenuItem_Click_1);
            // 
            // paletasToolStripMenuItem
            // 
            this.paletasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tipo1ToolStripMenuItem,
            this.tipo2ToolStripMenuItem2,
            this.tipo3ToolStripMenuItem1,
            this.tipo4ToolStripMenuItem,
            this.tipo5ToolStripMenuItem,
            this.tipo6ToolStripMenuItem});
            this.paletasToolStripMenuItem.Name = "paletasToolStripMenuItem";
            this.paletasToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.paletasToolStripMenuItem.Text = "Paletas";
            // 
            // tipo1ToolStripMenuItem
            // 
            this.tipo1ToolStripMenuItem.Name = "tipo1ToolStripMenuItem";
            this.tipo1ToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.tipo1ToolStripMenuItem.Text = "Tipo 1";
            this.tipo1ToolStripMenuItem.Click += new System.EventHandler(this.tipo1ToolStripMenuItem_Click_1);
            // 
            // tipo2ToolStripMenuItem2
            // 
            this.tipo2ToolStripMenuItem2.Name = "tipo2ToolStripMenuItem2";
            this.tipo2ToolStripMenuItem2.Size = new System.Drawing.Size(106, 22);
            this.tipo2ToolStripMenuItem2.Text = "Tipo 2";
            this.tipo2ToolStripMenuItem2.Click += new System.EventHandler(this.tipo2ToolStripMenuItem2_Click);
            // 
            // tipo3ToolStripMenuItem1
            // 
            this.tipo3ToolStripMenuItem1.Name = "tipo3ToolStripMenuItem1";
            this.tipo3ToolStripMenuItem1.Size = new System.Drawing.Size(106, 22);
            this.tipo3ToolStripMenuItem1.Text = "Tipo 3";
            this.tipo3ToolStripMenuItem1.Click += new System.EventHandler(this.tipo3ToolStripMenuItem1_Click);
            // 
            // tipo4ToolStripMenuItem
            // 
            this.tipo4ToolStripMenuItem.Name = "tipo4ToolStripMenuItem";
            this.tipo4ToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.tipo4ToolStripMenuItem.Text = "Tipo 4";
            this.tipo4ToolStripMenuItem.Click += new System.EventHandler(this.tipo4ToolStripMenuItem_Click);
            // 
            // tipo5ToolStripMenuItem
            // 
            this.tipo5ToolStripMenuItem.Name = "tipo5ToolStripMenuItem";
            this.tipo5ToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.tipo5ToolStripMenuItem.Text = "Tipo 5";
            this.tipo5ToolStripMenuItem.Click += new System.EventHandler(this.tipo5ToolStripMenuItem_Click);
            // 
            // tipo6ToolStripMenuItem
            // 
            this.tipo6ToolStripMenuItem.Name = "tipo6ToolStripMenuItem";
            this.tipo6ToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.tipo6ToolStripMenuItem.Text = "Tipo 6";
            this.tipo6ToolStripMenuItem.Click += new System.EventHandler(this.tipo6ToolStripMenuItem_Click);
            // 
            // tapetesDeberToolStripMenuItem
            // 
            this.tapetesDeberToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aguaToolStripMenuItem,
            this.hieloToolStripMenuItem});
            this.tapetesDeberToolStripMenuItem.Name = "tapetesDeberToolStripMenuItem";
            this.tapetesDeberToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.tapetesDeberToolStripMenuItem.Text = "Tapetes Deber";
            // 
            // aguaToolStripMenuItem
            // 
            this.aguaToolStripMenuItem.Name = "aguaToolStripMenuItem";
            this.aguaToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.aguaToolStripMenuItem.Text = "Agua";
            this.aguaToolStripMenuItem.Click += new System.EventHandler(this.aguaToolStripMenuItem_Click);
            // 
            // hieloToolStripMenuItem
            // 
            this.hieloToolStripMenuItem.Name = "hieloToolStripMenuItem";
            this.hieloToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.hieloToolStripMenuItem.Text = "Hielo";
            this.hieloToolStripMenuItem.Click += new System.EventHandler(this.hieloToolStripMenuItem_Click);
            // 
            // parcialIIIToolStripMenuItem
            // 
            this.parcialIIIToolStripMenuItem.Name = "parcialIIIToolStripMenuItem";
            this.parcialIIIToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.parcialIIIToolStripMenuItem.Text = "Parcial III";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(710, 338);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 88);
            this.button1.TabIndex = 20;
            this.button1.Text = "PARABOLA";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_4);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.Location = new System.Drawing.Point(710, 244);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 88);
            this.button3.TabIndex = 21;
            this.button3.Text = "PROYECCIONES";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_3);
            // 
            // labelX
            // 
            this.labelX.AutoSize = true;
            this.labelX.Location = new System.Drawing.Point(726, 39);
            this.labelX.Name = "labelX";
            this.labelX.Size = new System.Drawing.Size(38, 15);
            this.labelX.TabIndex = 22;
            this.labelX.Text = "label1";
            // 
            // labelY
            // 
            this.labelY.AutoSize = true;
            this.labelY.Location = new System.Drawing.Point(726, 65);
            this.labelY.Name = "labelY";
            this.labelY.Size = new System.Drawing.Size(38, 15);
            this.labelY.TabIndex = 23;
            this.labelY.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(822, 532);
            this.Controls.Add(this.labelY);
            this.Controls.Add(this.labelX);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Andres Gavino";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox1;
        private Button button2;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem parcial1ToolStripMenuItem;
        private ToolStripMenuItem parcial2ToolStripMenuItem;
        private ToolStripMenuItem parcialIIIToolStripMenuItem;
        private ToolStripMenuItem encerderPixelToolStripMenuItem;
        private ToolStripMenuItem pintarBanderaToolStripMenuItem;
        private ToolStripMenuItem degradarToolStripMenuItem;
        private ToolStripMenuItem normalToolStripMenuItem;
        private ToolStripMenuItem parabolaToolStripMenuItem;
        private ToolStripMenuItem lazoToolStripMenuItem;
        private ToolStripMenuItem margaritaToolStripMenuItem;
        private ToolStripMenuItem encenderToolStripMenuItem;
        private ToolStripMenuItem apagarToolStripMenuItem;
        private ToolStripMenuItem gFuncionesToolStripMenuItem;
        private ToolStripMenuItem testsToolStripMenuItem;
        private ToolStripMenuItem animacionToolStripMenuItem;
        private ToolStripMenuItem deberesToolStripMenuItem;
        private ToolStripMenuItem graficosToolStripMenuItem;
        private ToolStripMenuItem graficoToolStripMenuItem1;
        private ToolStripMenuItem examenToolStripMenuItem;
        private ToolStripMenuItem planoCartesianoToolStripMenuItem;
        private ToolStripMenuItem axonometriaToolStripMenuItem;
        private ToolStripMenuItem segmento3DToolStripMenuItem;
        private ToolStripMenuItem superficieRToolStripMenuItem;
        private ToolStripMenuItem tipo1ToolStripMenuItem1;
        private ToolStripMenuItem superficieVToolStripMenuItem;
        private ToolStripMenuItem tipo1ToolStripMenuItem2;
        private ToolStripMenuItem tipo2ToolStripMenuItem1;
        private ToolStripMenuItem correcionToolStripMenuItem;
        private ToolStripMenuItem tipo2ToolStripMenuItem;
        private ToolStripMenuItem animacionToolStripMenuItem1;
        private ToolStripMenuItem tipo3ToolStripMenuItem;
        private ToolStripMenuItem tipo4HiperboloiddeToolStripMenuItem;
        private ToolStripMenuItem paletasToolStripMenuItem;
        private ToolStripMenuItem tipo1ToolStripMenuItem;
        private ToolStripMenuItem tipo2ToolStripMenuItem2;
        private ToolStripMenuItem tipo3ToolStripMenuItem1;
        private ToolStripMenuItem tipo4ToolStripMenuItem;
        private ToolStripMenuItem tipo5ToolStripMenuItem;
        private ToolStripMenuItem tipo6ToolStripMenuItem;
        private ToolStripMenuItem tapetesDeberToolStripMenuItem;
        private ToolStripMenuItem aguaToolStripMenuItem;
        private ToolStripMenuItem hieloToolStripMenuItem;
        private Button button1;
        private Button button3;
        private Label labelX;
        private Label labelY;
    }
}